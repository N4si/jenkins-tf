import json
import boto3
import psycopg2
from decimal import Decimal
from datetime import datetime
from botocore.exceptions import ClientError


def get_secret(secret_name):
    """Retrieve the secret value from AWS Secrets Manager."""
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager')
    
    try:
        # Retrieve the secret value
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    except ClientError as e:
        # Handle exceptions
        raise e
    
    # Decrypt the secret if it's in SecretString format
    if 'SecretString' in get_secret_value_response:
        return json.loads(get_secret_value_response['SecretString'])
    else:
        return base64.b64decode(get_secret_value_response['SecretBinary'])


def json_serializer(obj):
    """Custom JSON serializer for Decimal and datetime objects."""
    if isinstance(obj, Decimal):
        return float(obj)  # Convert Decimal to float
    elif isinstance(obj, datetime):
        return obj.isoformat()  # Convert datetime to ISO 8601 string
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def lambda_handler(event, context):
    """Lambda function handler to connect to RDS and execute a query."""
    secret_name = "ec-exhibits-dev-postgres"  # Name of your secret in Secrets Manager
    secret = get_secret(secret_name)
    
    # RDS database credentials from the secret
    db_host = secret['host']
    db_port = secret['port']
    db_name = "exhibits_dev"  # Replace with your actual DB name
    db_user = secret['username']
    db_password = secret['password']
    
    # Create a connection to the PostgreSQL RDS instance
    try:
        connection = psycopg2.connect(
            host=db_host,
            port=db_port,
            dbname=db_name,
            user=db_user,
            password=db_password
        )
        cursor = connection.cursor()
        
        # Query to execute
        query = """
        WITH leas_grpd
            AS (SELECT rd_1.leas_request_id,
                        CASE
                        WHEN Bool_and(( rd_1.data_dump ->> 'status' ) :: text = 'Pass'
                            )
                        THEN
                        'Pass'
                        ELSE 'Fail'
                        END AS status_summary
                FROM   exhibits_data.response_data rd_1
                GROUP  BY rd_1.leas_request_id)
        SELECT rd.leas_request_id    AS "RequestID",
            er.requestor_name     AS "SubmitterName",
            er.business_area      AS "BusinessArea",
            er.exhibit_amount     AS "EventCost",
            er.event_name         AS "EventVenue",
            er.exhibit_start_date AS "EventDate",
            er.payment_type       AS "PaymentMethod",
            er.approver1_name     AS "ApproverName1",
            er.approver2_name     AS "ApproverName2",
            er.approver3_name     AS "ApproverName3",
            rd.status_summary
        FROM   leas_grpd rd
            left join exhibits_data.exhibit_requests er
                    ON er.leas_request_id = rd.leas_request_id :: text; 
        """
        cursor.execute(query)
        
        # Fetch query results
        results = cursor.fetchall()
        column_names = [desc[0] for desc in cursor.description]  # Extract column names
        
        # Format results as a list of dictionaries
        formatted_results = [
            dict(zip(column_names, row)) for row in results
        ]
        
        # Close the cursor and connection
        cursor.close()
        connection.close()

        # Returning the query results as a JSON response
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Query executed successfully',
                'results': formatted_results
            }, default=json_serializer)  # Use custom serializer
        }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Failed to execute query',
                'error': str(e)
            })
        }